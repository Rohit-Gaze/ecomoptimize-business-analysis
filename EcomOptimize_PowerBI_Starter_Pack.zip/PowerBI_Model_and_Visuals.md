# Power BI Model and Report Layout

## Data model
Import the three CSV files. Create these one-to-many relationships:
- `checkout_sessions[session_id]` (1) → `orders[session_id]` (*)
- `orders[order_id]` (1) → `returns_refunds[order_id]` (*)

Use single-direction filtering from the parent table to the child table. Do not create many-to-many relationships.

## Page 1 — Executive Overview
- KPI cards: Total Checkout Sessions, Completed Orders, Checkout Conversion Rate, Checkout Abandonment Rate, Gross Order Revenue, Average Order Value.
- Line chart: revenue by order month (use `orders[order_date]`).
- Bar chart: orders by device (use `checkout_sessions[device_type]` and Completed Orders).
- Slicers: session date, device type, traffic source.

## Page 2 — Checkout & Payment
- Funnel or stacked bar: checkout stage reached by session count.
- Bar chart: payment failure rate by payment method.
- Column chart: conversion rate by device.
- Matrix: traffic source × customer type with sessions and conversion.
- Slicers: session date, device, payment method, traffic source.

Note: “stage reached” is the furthest stage recorded per session in this synthetic dataset, not event-level funnel telemetry. Label the visual accordingly.

## Page 3 — Returns & Refunds
- KPI cards: Delivered Orders, Returned Delivered Orders, Return Rate, Average Refund Turnaround (Days).
- Bar chart: return cases by reason.
- Donut chart: refund status.
- Table: return ID, order ID, reason, request date, completion date, status.
- Slicers: return reason, refund status.

## Validation
- Compare the KPI cards against SQL/Excel outputs using the same definitions.
- Conversion and abandonment should sum to 100% when sessions are either completed or not completed.
- Payment failure rate denominator includes only sessions with an attempted payment (Success or Failed).
- Return rate denominator is delivered orders; numerator is distinct delivered orders with a return record.
- Average refund turnaround uses completed cases only.
- All data is synthetic; do not describe the metrics as actual business performance.

## Publishing
Save the report as `EcomOptimize.pbix`. Publishing to Power BI Service and sharing reports may require an eligible account/licence and sharing permissions. Do not assume a public share link is available.
