# EcomOptimize Power BI Starter Pack

This starter pack contains synthetic data for a portfolio case study. It is not real company or customer data.

## Files
- `checkout_sessions.csv`: 3,000 checkout sessions
- `orders.csv`: 1,551 completed orders
- `returns_refunds.csv`: 158 return/refund cases
- `PowerBI_DAX_Measures.txt`: DAX measure definitions
- `PowerBI_Model_and_Visuals.md`: model setup and report layout
- `ecomoptimize_analysis.sql`: SQLite query practice script (if included)

## Import into Power BI Desktop
1. Open Power BI Desktop.
2. Home → Get data → Text/CSV.
3. Import all three CSV files.
4. In Model view, create these relationships:
   - `checkout_sessions[session_id]` (1) → `orders[session_id]` (*)
   - `orders[order_id]` (1) → `returns_refunds[order_id]` (*)
5. Use single-direction filtering from checkout sessions to orders and orders to returns.
6. Set date columns to Date type and amount columns to Decimal Number.
7. Create the measures in `PowerBI_DAX_Measures.txt`.
8. Build report pages following `PowerBI_Model_and_Visuals.md`.

## Definitions
- Checkout conversion = completed orders / checkout sessions.
- Abandonment = checkout sessions without completed orders / checkout sessions.
- Payment failure rate = failed payment attempts / all payment attempts.
- Return rate = distinct returned delivered orders / delivered orders.
- Average refund turnaround = average calendar days from refund request to completion, completed refunds only.

The dataset uses ISO dates and INR amounts. Check all relationships and measures after import.
